
import BookingForm from './BookingForm';

function BookingPage() {
  return (
    <main>
      <BookingForm />
    </main>
  );
}
export default BookingPage;